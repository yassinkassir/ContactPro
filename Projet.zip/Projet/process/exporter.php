<?php
require_once '../config/database.php';

// 1. Définir le nom du fichier avec la date du jour
$filename = "export_contacts_" . date('Y-m-d') . ".csv";

// 2. Configurer les headers pour le téléchargement
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=' . $filename);

// 3. Ouvrir le flux de sortie (php://output)
$output = fopen('php://output', 'w');

// 4. Ajouter le BOM UTF-8 pour que Excel affiche bien les accents (Ex: é, à, ç)
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

// 5. Définir les en-têtes des colonnes
fputcsv($output, ['ID', 'Nom', 'Prénom', 'Email', 'Téléphone', 'Date de création'], ';');

// 6. Récupérer les données de la base
$query = $pdo->query("SELECT id, nom, prenom, email, telephone, date_creation FROM contacts ORDER BY nom ASC");

while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
    // On formate la date avant l'export
    $row['date_creation'] = date('d/m/Y', strtotime($row['date_creation']));
    
    // On écrit la ligne dans le CSV (avec le point-virgule comme séparateur pour Excel)
    fputcsv($output, $row, ';');
}

// 7. Fermer le flux
fclose($output);
exit;