<?php
require_once '../config/database.php';

// 1. Récupération de l'ID depuis l'URL
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header("Location: ../index.php");
    exit;
}

// 2. Requête pour obtenir les infos du contact
$stmt = $pdo->prepare("SELECT * FROM contacts WHERE id = ?");
$stmt->execute([$id]);
$contact = $stmt->fetch();

if (!$contact) {
    die("Contact introuvable.");
}

include '../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
                <h4 class="mb-0">Détails du Contact</h4>
                <a href="../index.php" class="btn btn-sm btn-light">Retour</a>
            </div>
            <div class="card-body">
                <div class="text-center mb-4">
                    <div class="display-1 text-muted">👤</div>
                    <h3 class="mt-2"><?= htmlspecialchars($contact['prenom'] . ' ' . $contact['nom']) ?></h3>
                    <span class="badge bg-secondary">ID: #<?= $contact['id'] ?></span>
                </div>

                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><strong>📧 Email :</strong> <?= htmlspecialchars($contact['email']) ?></li>
                    <li class="list-group-item"><strong>📞 Téléphone :</strong> <?= htmlspecialchars($contact['telephone'] ?: 'Non renseigné') ?></li>
                    <li class="list-group-item"><strong>🎂 Date de naissance :</strong> <?= $contact['date_naissance'] ? date('d/m/Y', strtotime($contact['date_naissance'])) : 'Inconnue' ?></li>
                    <li class="list-group-item"><strong>📍 Adresse :</strong><br><?= nl2br(htmlspecialchars($contact['adresse'] ?: 'Aucune adresse')) ?></li>
                    <li class="list-group-item"><strong>📝 Notes :</strong><br><?= nl2br(htmlspecialchars($contact['notes'] ?: 'Pas de notes.')) ?></li>
                </ul>
            </div>
            <div class="card-footer text-muted small">
                Créé le : <?= date('d/m/Y H:i', strtotime($contact['date_creation'])) ?><br>
                Dernière modification : <?= date('d/m/Y H:i', strtotime($contact['date_modification'])) ?>
            </div>
        </div>
        
        <div class="mt-3 d-flex gap-2">
            <a href="modifier.php?id=<?= $contact['id'] ?>" class="btn btn-warning w-100">Modifier</a>
            <button onclick="window.print()" class="btn btn-outline-secondary w-100">Imprimer</button>
        </div>
    </div>
</div>
<?php
include '../includes/footer.php'; 
?>
