<?php
require_once '../config/database.php';

// Récupérer la recherche (q pour query)
$search = isset($_GET['q']) ? trim($_GET['q']) : '';

// Requête SQL avec LIKE pour chercher partout
$sql = "SELECT * FROM contacts 
        WHERE nom LIKE :search 
        OR prenom LIKE :search 
        OR email LIKE :search 
        OR telephone LIKE :search 
        ORDER BY nom ASC 
        LIMIT 20";

$stmt = $pdo->prepare($sql);
$stmt->execute(['search' => "%$search%"]);
$contacts = $stmt->fetchAll();

// On génère uniquement les lignes du tableau
if (count($contacts) > 0) {
    foreach ($contacts as $c) {
        echo "<tr>";
        echo "<td><strong>" . htmlspecialchars($c['nom']) . "</strong></td>";
        echo "<td>" . htmlspecialchars($c['prenom']) . "</td>";
        echo "<td>" . htmlspecialchars($c['email']) . "</td>";
        echo "<td>" . htmlspecialchars($c['telephone']) . "</td>";
        echo "<td>" . date('d/m/Y', strtotime($c['date_creation'])) . "</td>";
        echo "<td class='text-center'>
                <div class='btn-group shadow-sm'> 
                    <a href='process/voir.php?id={$c['id']}' class='btn btn-sm btn-outline-info'>👁️</a>
                    <a href='process/modifier.php?id={$c['id']}' class='btn btn-sm btn-outline-warning'>✏️</a>
                    <a href='process/supprimer.php?id={$c['id']}' class='btn btn-sm btn-outline-danger' onclick='return confirm(\"Supprimer ce contact ?\")'>🗑️</a>
                </div>
              </td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6' class='text-center py-4 text-muted'>Aucun contact ne correspond à votre recherche.</td></tr>";
}

