<?php
require_once '../config/database.php';

// 1. On récupère l'ID et on s'assure que c'est un nombre
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    try {
        // 2. Préparation de la requête de suppression
        $stmt = $pdo->prepare("DELETE FROM contacts WHERE id = ?");
        $stmt->execute([$id]);
        
        // 3. Redirection avec un message de succès (optionnel)
        header("Location: ../index.php?deleted=1");
        exit;
    } catch (PDOException $e) {
        die("Erreur lors de la suppression : " . $e->getMessage());
    }
} else {
    // Si l'ID est invalide, on retourne à l'index
    header("Location: ../index.php");
    exit;
}