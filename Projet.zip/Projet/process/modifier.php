<?php
require_once '../config/database.php';
$error = "";
$success = "";

// 1. Vérification de l'ID passé en paramètre
if (!isset($_GET['id']) || empty($_GET['id'])) {
   header("Location: ../index.php");
    exit;
}

$id = (int)$_GET['id'];

// 2. Récupération des données du contact pour le pré-remplissage
$stmt = $pdo->prepare("SELECT * FROM contacts WHERE id = ?");
$stmt->execute([$id]);
$contact = $stmt->fetch();

if (!$contact) {
    header("Location: index.php");
    exit;
}

// 3. Traitement du formulaire de modification
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim(htmlspecialchars($_POST['nom']));
    $prenom = trim(htmlspecialchars($_POST['prenom']));
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $telephone = trim(htmlspecialchars($_POST['telephone']));
    $adresse = trim(htmlspecialchars($_POST['adresse']));
    $date_naissance = $_POST['date_naissance'];
    $notes = trim(htmlspecialchars($_POST['notes']));

    // Validation de l'email unique (sauf pour le contact lui-même)
    $checkEmail = $pdo->prepare("SELECT id FROM contacts WHERE email = ? AND id != ?");
    $checkEmail->execute([$email, $id]);
    
    if ($checkEmail->rowCount() > 0) {
        $error = "Cet email est déjà utilisé par un autre contact.";
    } else {
        try {
            // Note : le champ 'date_modification' se met à jour automatiquement grâce à CURRENT_TIMESTAMP ON UPDATE
            $sql = "UPDATE contacts SET 
                    nom = :nom, 
                    prenom = :prenom, 
                    email = :email, 
                    telephone = :tel, 
                    adresse = :adr, 
                    date_naissance = :dob, 
                    notes = :notes 
                    WHERE id = :id";
            
            $update = $pdo->prepare($sql);
            $update->execute([
                ':nom'    => $nom,
                ':prenom' => $prenom,
                ':email'  => $email,
                ':tel'    => $telephone,
                ':adr'    => $adresse,
                ':dob'    => $date_naissance,
                ':notes'  => $notes,
                ':id'     => $id
            ]);
            
            $success = "Contact mis à jour avec succès !";
            // On rafraîchit les données pour l'affichage
            $stmt->execute([$id]);
            $contact = $stmt->fetch();
            
        } catch (PDOException $e) {
            $error = "Erreur lors de la modification : " . $e->getMessage();
        }
    }
}

include '../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow border-0">
            <div class="card-header bg-warning text-dark py-3">
                <h4 class="mb-0">✏️ Modifier le contact</h4>
            </div>
            <div class="card-body p-4">
                
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?= $error ?></div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success"><?= $success ?></div>
                    <script>setTimeout(() => window.location.href='../index.php', 1500);</script>
                <?php endif; ?>

                <form method="POST" class="needs-validation" novalidate>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Nom</label>
                            <input type="text" name="nom" class="form-control" value="<?= htmlspecialchars($contact['nom']) ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Prénom</label>
                            <input type="text" name="prenom" class="form-control" value="<?= htmlspecialchars($contact['prenom']) ?>" required>
                        </div>
                        <div class="col-md-7">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($contact['email']) ?>" required>
                        </div>
                        <div class="col-md-5">
                            <label class="form-label">Téléphone</label>
                            <input type="text" name="telephone" class="form-control" value="<?= htmlspecialchars($contact['telephone']) ?>">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">Date de Naissance</label>
                            <input type="date" name="date_naissance" class="form-control" value="<?= $contact['date_naissance'] ?>">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">Adresse</label>
                            <textarea name="adresse" class="form-control" rows="2"><?= htmlspecialchars($contact['adresse']) ?></textarea>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" class="form-control" rows="2"><?= htmlspecialchars($contact['notes']) ?></textarea>
                        </div>
                        <div class="col-12 mt-2">
                            <small class="text-muted">
                                📅 Ajouté le : <?= date('d/m/Y H:i', strtotime($contact['date_creation'])) ?><br>
                                🔄 Dernière modification : <?= date('d/m/Y H:i', strtotime($contact['date_modification'])) ?>
                            </small>
                        </div>
                    </div>

                    <div class="mt-4 border-top pt-3 d-flex justify-content-end gap-2">
                        <a href="../index.php" class="btn btn-light">Annuler</a>
                        <button type="submit" class="btn btn-warning px-4">Enregistrer les modifications</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Réutilisation de la validation Bootstrap
(function () {
  'use strict'
  var forms = document.querySelectorAll('.needs-validation')
  Array.prototype.slice.call(forms).forEach(function (form) {
    form.addEventListener('submit', function (event) {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }
      form.classList.add('was-validated')
    }, false)
  })
})()
</script>

<?php
include '../includes/footer.php'; 
?>