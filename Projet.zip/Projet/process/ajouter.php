<?php
require_once '../config/database.php';
$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Nettoyage des données
    $nom = trim(htmlspecialchars($_POST['nom']));
    $prenom = trim(htmlspecialchars($_POST['prenom']));
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $telephone = trim(htmlspecialchars($_POST['telephone']));
    $adresse = trim(htmlspecialchars($_POST['adresse']));
    $date_naissance = $_POST['date_naissance'];
    $notes = trim(htmlspecialchars($_POST['notes']));

    // 1. Vérification côté serveur : Email unique
    $checkEmail = $pdo->prepare("SELECT id FROM contacts WHERE email = ?");
    $checkEmail->execute([$email]);
    
    if ($checkEmail->rowCount() > 0) {
        $error = "Désolé, cet email appartient déjà à un autre contact.";
    } else {
        // 2. Insertion en base de données
        try {
            $sql = "INSERT INTO contacts (nom, prenom, email, telephone, adresse, date_naissance, notes) 
                    VALUES (:nom, :prenom, :email, :tel, :adr, :dob, :notes)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':nom'   => $nom,
                ':prenom' => $prenom,
                ':email'  => $email,
                ':tel'    => $telephone,
                ':adr'    => $adresse,
                ':dob'    => $date_naissance,
                ':notes'  => $notes
            ]);
            $success = "Le contact a été ajouté avec succès !";
        } catch (PDOException $e) {
            $error = "Erreur lors de l'enregistrement : " . $e->getMessage();
        }
    }
}

include '../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow border-0">
            <div class="card-header bg-primary text-white py-3">
                <h4 class="mb-0">Ajouter un nouveau contact</h4>
            </div>
            <div class="card-body p-4">
                
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?= $error ?></div>
                <?php endif; ?>

                <?php if ($success): ?>
                    <div class="alert alert-success"><?= $success ?></div>
                    <script>setTimeout(() => window.location.href='../index.php', 2000);</script>
                <?php endif; ?>

                <form id="contactForm" method="POST" class="needs-validation" novalidate>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Nom <span class="text-danger">*</span></label>
                            <input type="text" name="nom" class="form-control" required>
                            <div class="invalid-feedback">Le nom est obligatoire.</div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Prénom <span class="text-danger">*</span></label>
                            <input type="text" name="prenom" class="form-control" required>
                            <div class="invalid-feedback">Le prénom est obligatoire.</div>
                        </div>
                        <div class="col-md-7">
                            <label class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" name="email" class="form-control" required>
                            <div class="invalid-feedback">Veuillez entrer un email valide.</div>
                        </div>
                        <div class="col-md-5">
                            <label class="form-label">Téléphone</label>
                            <input type="text" name="telephone" class="form-control" placeholder="06XXXXXXXX">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">Date de Naissance</label>
                            <input type="date" name="date_naissance" class="form-control">
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">Adresse</label>
                            <textarea name="adresse" class="form-control" rows="2"></textarea>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label">Notes</label>
                            <textarea name="notes" class="form-control" rows="2" placeholder="Informations complémentaires..."></textarea>
                        </div>
                    </div>

                    <div class="mt-4 border-top pt-3 d-flex justify-content-end gap-2">
                        <a href="../index.php" class="btn btn-light">Annuler</a>
                        <button type="submit" class="btn btn-primary px-4">Enregistrer le contact</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Validation Bootstrap côté client
(function () {
  'use strict'
  var forms = document.querySelectorAll('.needs-validation')
  Array.prototype.slice.call(forms).forEach(function (form) {
    form.addEventListener('submit', function (event) {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }
      form.classList.add('was-validated')
    }, false)
  })
})()
</script>

<?php
include '../includes/footer.php'; 
?>