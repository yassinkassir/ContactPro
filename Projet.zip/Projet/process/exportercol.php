<?php
require_once '../config/database.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    die("ID de contact invalide.");
}

// Récupération du contact spécifique
$stmt = $pdo->prepare("SELECT id, nom, prenom, email, telephone, date_creation FROM contacts WHERE id = ?");
$stmt->execute([$id]);
$contact = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$contact) {
    die("Contact introuvable.");
}

$filename = "contact_" . $contact['nom'] . "_" . $contact['prenom'] . ".csv";

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$output = fopen('php://output', 'w');
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

fputcsv($output, ['ID', 'Nom', 'Prénom', 'Email', 'Téléphone', 'Date Ajout'], ';');
fputcsv($output, $contact, ';');

fclose($output);
exit();