<?php
require_once 'config/database.php';

// --- CONFIGURATION DE LA PAGINATION ---
$limit = 10; // Nombre de contacts par page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

// --- CONFIGURATION DU TRI ---
$sort_columns = ['nom', 'prenom', 'date_creation'];
$order_by = isset($_GET['sort']) && in_array($_GET['sort'], $sort_columns) ? $_GET['sort'] : 'nom';
$order_dir = isset($_GET['dir']) && $_GET['dir'] === 'desc' ? 'DESC' : 'ASC';
$next_dir = ($order_dir === 'ASC') ? 'desc' : 'asc';

// --- RÉCUPÉRATION DES DONNÉES ---
// Compter le total pour la pagination
$total_contacts = $pdo->query("SELECT COUNT(*) FROM contacts")->fetchColumn();
$total_pages = ceil($total_contacts / $limit);

// Requête principale
$sql = "SELECT * FROM contacts ORDER BY $order_by $order_dir LIMIT :limit OFFSET :offset";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$contacts = $stmt->fetchAll();

include 'includes/header.php';
?>

<div class="container py-5">
    <div class="p-4 mb-4 bg-white shadow-sm rounded-4 border-start border-primary border-5">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
            <div>
                <h2 class="fw-bold mb-1 text-dark">
                    <i class="bi bi-person-lines-fill text-primary"></i> Répertoire Contacts
                </h2>
                <p class="text-muted mb-0">Gérez vos relations professionnelles en toute simplicité.</p>
            </div>
            <div >
                <a href="process/ajouter.php" class="btn btn-primary rounded-pill px-4 shadow-sm fw-bold">
                    + Nouveau Contact
                </a>
            </div>
        </div>
    </div>

  

    
</div>

<div class="mb-3">
    <input type="text" id="search" class="form-control" placeholder="Rechercher un nom, email ou téléphone...">
</div>

<div class="table-responsive shadow-sm bg-white rounded">
    <table class="table table-hover align-middle mb-0">
        <thead class="table-light">
            <tr>
                <th><a href="?sort=nom&dir=<?= $next_dir ?>">Nom</a></th>
                <th><a href="?sort=prenom&dir=<?= $next_dir ?>">Prénom</a></th>
                <th>Email</th>
                <th>Téléphone</th>
                <th><a href="?sort=date_creation&dir=<?= $next_dir ?>">Ajouté le</a></th>
                <th class="text-center">Actions</th>
            </tr>
        </thead>
        <tbody id="contact-table">
            <?php if (count($contacts) > 0): ?>
                <?php foreach ($contacts as $c): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($c['nom']) ?></strong></td>
                    <td><?= htmlspecialchars($c['prenom']) ?></td>
                    <td><a href="mailto:<?= $c['email'] ?>"><?= htmlspecialchars($c['email']) ?></a></td>
                    <td><?= htmlspecialchars($c['telephone']) ?></td>
                    <td><?= date('d/m/Y', strtotime($c['date_creation'])) ?></td>
                    <td class="text-center">
                        <div class="btn-group shadow-sm">
                            <a href="process/voir.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-info" title="Voir">👁️</a>
                            <a href="process/modifier.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-warning" title="Modifier">✏️</a>
                            <a href="process/supprimer.php?id=<?= $c['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Supprimer ce contact ?')" title="Supprimer">🗑️</a>
                            <a href="process/exportercol.php?id=<?= $c['id'] ?>" class="btn btn-outline-success d-inline-flex align-items-center gap-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" viewBox="0 0 16 16">
                                   <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"/>
                                   <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"/>
                                </svg>
    
                              </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="6" class="text-center py-4 text-muted">Aucun contact trouvé.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<nav class="mt-4">
    <ul class="pagination justify-content-center">
        <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
            <a class="page-link" href="?page=<?= $page - 1 ?>&sort=<?= $order_by ?>&dir=<?= $order_dir ?>">Précédent</a>
        </li>
        
        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <li class="page-item <?= ($page == $i) ? 'active' : '' ?>">
                <a class="page-link" href="?page=<?= $i ?>&sort=<?= $order_by ?>&dir=<?= $order_dir ?>"><?= $i ?></a>
            </li>
        <?php endfor; ?>

        <li class="page-item <?= ($page >= $total_pages) ? 'disabled' : '' ?>">
            <a class="page-link" href="?page=<?= $page + 1 ?>&sort=<?= $order_by ?>&dir=<?= $order_dir ?>">Suivant</a>
        </li>
    </ul>
</nav>

<script>
// On sélectionne l'input de recherche et le corps du tableau
const searchInput = document.getElementById('search');
const tableBody = document.getElementById('contact-table');

searchInput.addEventListener('input', function() {
    const query = this.value;

    // On utilise Fetch API pour appeler rechercher.php sans recharger la page
    fetch('process/rechercher.php?q=' + encodeURIComponent(query))
        .then(response => {
            if (!response.ok) throw new Error('Erreur réseau');
            return response.text();
        })
        .then(html => {
            // On remplace le contenu du tableau par les résultats reçus
            tableBody.innerHTML = html;
        })
        .catch(error => {
            console.error('Erreur AJAX:', error);
        });
});
</script>

<?php
include 'includes/footer.php'; 
?>