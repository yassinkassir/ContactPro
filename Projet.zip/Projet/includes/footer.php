</main> <footer class="bg-white border-top py-4 mt-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start">
                <span class="text-muted">
                    &copy; <?= date('Y'); ?> <strong>ContactPro</strong>. Tous droits réservés.
                </span>
            </div>
            
            <div class="col-md-6 text-center text-md-end">
                <ul class="list-inline mb-0">
                    <li class="list-inline-item">
                        <small class="text-muted">Version 1.0</small>
                    </li>
                    <li class="list-inline-item ms-3">
                        <a href="#" class="text-decoration-none text-primary fw-bold" onclick="window.scrollTo({top: 0, behavior: 'smooth'}); return false;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-up-circle-fill" viewBox="0 0 16 16">
                                <path d="M16 8A8 8 0 1 0 0 8a8 8 0 0 0 16 0m-7.5 3.5a.5.5 0 0 1-1 0V5.707L5.354 7.854a.5.5 0 1 1-.708-.708l3-3a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 5.707z"/>
                            </svg>
                            Haut de page
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<script src="bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>